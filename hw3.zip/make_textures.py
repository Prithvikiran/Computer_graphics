#!/usr/bin/env python3
# Procedurally generate the small 128x128 24-bit BMP textures used by hw3.
# Standard library only. BMP is written as standard bottom-up BGR so that
# loadtexbmp.c (which swaps BGR->RGB) reads them correctly.
import struct, random, math

W = H = 128

def write_bmp(path, pix):
    # pix: list of H rows (top->bottom), each a list of W (r,g,b) tuples 0..255
    row_bytes = W * 3
    pad = (4 - (row_bytes % 4)) % 4          # rows padded to 4 bytes (none for 128)
    img_size = (row_bytes + pad) * H
    file_size = 54 + img_size
    with open(path, "wb") as f:
        # BITMAPFILEHEADER (14 bytes)
        f.write(b"BM")
        f.write(struct.pack("<IHHI", file_size, 0, 0, 54))
        # BITMAPINFOHEADER (40 bytes)
        f.write(struct.pack("<IiiHHIIiiII",
                            40, W, H, 1, 24, 0, img_size, 2835, 2835, 0, 0))
        # Pixel data, bottom row first, BGR order
        for y in range(H - 1, -1, -1):
            for x in range(W):
                r, g, b = pix[y][x]
                f.write(bytes((b & 255, g & 255, r & 255)))
            if pad:
                f.write(b"\x00" * pad)

def clamp(v):
    return 0 if v < 0 else 255 if v > 255 else int(v)

# ---- grass: green base, noisy, faint vertical blades --------------------
def grass():
    random.seed(1)
    p = [[(0, 0, 0)] * W for _ in range(H)]
    for y in range(H):
        for x in range(W):
            n = random.randint(-18, 18)
            blade = 10 if (x * 7 + y) % 11 < 2 else 0
            p[y][x] = (clamp(45 + n), clamp(115 + n + blade), clamp(40 + n))
    return p

# ---- wood: brown with vertical grain lines ------------------------------
def wood():
    random.seed(2)
    p = [[(0, 0, 0)] * W for _ in range(H)]
    for y in range(H):
        for x in range(W):
            grain = 22 * math.sin(x * 0.45 + 2.0 * math.sin(x * 0.06))
            n = random.randint(-8, 8)
            p[y][x] = (clamp(135 + grain + n),
                       clamp(92 + grain * 0.6 + n),
                       clamp(48 + grain * 0.3 + n))
    return p

# ---- metal: medium grey, horizontal brushed streaks ---------------------
def metal():
    random.seed(3)
    p = [[(0, 0, 0)] * W for _ in range(H)]
    for y in range(H):
        streak = 14 * math.sin(y * 0.8)
        for x in range(W):
            n = random.randint(-6, 6)
            v = 150 + streak + n
            p[y][x] = (clamp(v), clamp(v), clamp(v + 6))
    return p

# ---- plastic: light, smooth, very faint noise (modulated by bin colour) -
def plastic():
    random.seed(4)
    p = [[(0, 0, 0)] * W for _ in range(H)]
    for y in range(H):
        for x in range(W):
            n = random.randint(-4, 4)
            sheen = 12 * math.sin(x * 0.10)
            v = 210 + n + sheen
            p[y][x] = (clamp(v), clamp(v), clamp(v))
    return p

# ---- rubber: dark with raised tread ridges ------------------------------
def rubber():
    p = [[(0, 0, 0)] * W for _ in range(H)]
    for y in range(H):
        for x in range(W):
            ridge = 40 if (x % 12) < 5 else 0
            v = 28 + ridge
            p[y][x] = (v, v, v)
    return p

write_bmp("Textures/grass.bmp", grass())
write_bmp("Textures/wood.bmp", wood())
write_bmp("Textures/metal.bmp", metal())
write_bmp("Textures/plastic.bmp", plastic())
write_bmp("Textures/rubber.bmp", rubber())
print("textures written")
