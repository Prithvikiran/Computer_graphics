/*
 *  Homework 3 - Lighting and Textures
 *  Prithvikiran
 *  Per-block origins are noted in comments below using these tags:
 *    [hw2]   my Homework 2 (hw2.c)
 *    [ex14]  texture environment + key handling   (course example ex14.c)
 *    [ex15]  textured/cube                     (course example ex15.c)
 *    [ex17]  profile normals + lighting display    (course example ex17.c)
 *    [ex20]  textured cylinder (coin) lighting     (course example ex20.c)
 *    [ex21]  cube scene structure                  (course example ex21.c)
 *
 *  KEY BINDINGS
 *  ------------
 *    1 / 2 / 3   Select Overhead-Ortho / Overhead-Perspective / First-Person
 *    m / M       Cycle through the three view modes
 *    arrows      Overhead: orbit the scene;  First person: look around
 *    PgUp/PgDn   Overhead: zoom in / out
 *    w a s d     First person: walk forward / left / back / right
 *    l / L       Toggle lighting on / off
 *    space       Toggle automatic sun motion on / off
 *    , / .       Move the sun by hand (when stopped)
 *    t / T       Toggle textures on / off
 *    b / B       Toggle axes
 *    + / -       Increase / decrease field of view
 *    0           Reset the view and sun position
 *    ESC / q     Exit
 */
#include "CSCIx229.h"

/*  -----  View / projection state  [hw2] (originally based on ex9)  -----  */
int    mode = 1;     /*  0=overhead ortho, 1=overhead perspective, 2=first person  */
int    axes = 0;     /*  Display axes  */
int    th   = 35;    /*  Azimuth of view angle for the overhead modes  */
int    ph   = 30;    /*  Elevation of view angle for the overhead modes  */
int    fov  = 55;    /*  Field of view for perspective  */
double asp  = 1;     /*  Aspect ratio  */
double dim  = 9.0;   /*  Size of world  */

/*  -----  First person camera state  [hw2]  -----  */
double Ex = 0;       /*  Eye position X  */
double Ey = 1.3;     /*  Eye height (kept above the ground)  */
double Ez = 7;       /*  Eye position Z  */
double fpTh = 0;     /*  First person heading (yaw, degrees)  */
double fpPh = -8;    /*  First person pitch (degrees)  */

/*  -----  Lighting / sun state  [new for hw3]  -----  */
int    light = 1;    /*  Lighting on/off  */
int    move  = 1;    /*  Sun moves automatically  */
int    ntex  = 1;    /*  Textures on/off  */
float  zh    = 10;   /*  Sun angle: 0=East horizon, 90=noon, 180=West horizon  */
#define LR 9.35     /*  Radius of the sun arc; keep it inside the visible scene  */

#define FIELD 9.0    /*  Half width of the square field  [hw2]  */

unsigned int tex_grass, tex_wood, tex_metal, tex_plastic, tex_rubber;

static void Texture(unsigned int t)
{
   if (ntex)
   {
      glEnable(GL_TEXTURE_2D);
      glBindTexture(GL_TEXTURE_2D,t);
   }
   else
      glDisable(GL_TEXTURE_2D);
}

/* =========================================================
 *  PRIMITIVE BUILDERS
 * ========================================================= */

/*
 *  Generic textured unit cube centred at the origin.
 *  GEOMETRY from hw2 Cube(); NORMALS and TEXTURE COORDS added for hw3 using
 *  the per-face layout of ex15 cube().  Texture coordinates run from
 *  0..size on each axis so the texture repeats roughly once per world unit.
 *  [hw2 + ex15]
 */
static void CubeTex(double sx,double sy,double sz,float r,float g,float b)
{
   glColor3f(r,g,b);
   glBegin(GL_QUADS);
   /*  Top  (+Y)  */
   glNormal3f(0,+1,0);
   glTexCoord2d(0 ,0 ); glVertex3d(-0.5,+0.5,-0.5);
   glTexCoord2d(0 ,sz); glVertex3d(-0.5,+0.5,+0.5);
   glTexCoord2d(sx,sz); glVertex3d(+0.5,+0.5,+0.5);
   glTexCoord2d(sx,0 ); glVertex3d(+0.5,+0.5,-0.5);
   /*  Bottom (-Y)  */
   glNormal3f(0,-1,0);
   glTexCoord2d(0 ,0 ); glVertex3d(-0.5,-0.5,-0.5);
   glTexCoord2d(sx,0 ); glVertex3d(+0.5,-0.5,-0.5);
   glTexCoord2d(sx,sz); glVertex3d(+0.5,-0.5,+0.5);
   glTexCoord2d(0 ,sz); glVertex3d(-0.5,-0.5,+0.5);
   /*  Front (+Z)  */
   glNormal3f(0,0,+1);
   glTexCoord2d(0 ,0 ); glVertex3d(-0.5,-0.5,+0.5);
   glTexCoord2d(sx,0 ); glVertex3d(+0.5,-0.5,+0.5);
   glTexCoord2d(sx,sy); glVertex3d(+0.5,+0.5,+0.5);
   glTexCoord2d(0 ,sy); glVertex3d(-0.5,+0.5,+0.5);
   /*  Back (-Z)  */
   glNormal3f(0,0,-1);
   glTexCoord2d(0 ,0 ); glVertex3d(+0.5,-0.5,-0.5);
   glTexCoord2d(sx,0 ); glVertex3d(-0.5,-0.5,-0.5);
   glTexCoord2d(sx,sy); glVertex3d(-0.5,+0.5,-0.5);
   glTexCoord2d(0 ,sy); glVertex3d(+0.5,+0.5,-0.5);
   /*  Right (+X)  */
   glNormal3f(+1,0,0);
   glTexCoord2d(0 ,0 ); glVertex3d(+0.5,-0.5,+0.5);
   glTexCoord2d(sz,0 ); glVertex3d(+0.5,-0.5,-0.5);
   glTexCoord2d(sz,sy); glVertex3d(+0.5,+0.5,-0.5);
   glTexCoord2d(0 ,sy); glVertex3d(+0.5,+0.5,+0.5);
   /*  Left (-X)  */
   glNormal3f(-1,0,0);
   glTexCoord2d(0 ,0 ); glVertex3d(-0.5,-0.5,-0.5);
   glTexCoord2d(sz,0 ); glVertex3d(-0.5,-0.5,+0.5);
   glTexCoord2d(sz,sy); glVertex3d(-0.5,+0.5,+0.5);
   glTexCoord2d(0 ,sy); glVertex3d(-0.5,+0.5,-0.5);
   glEnd();
}

static void Box(double x,double y,double z,
                double dx,double dy,double dz,double ry,
                float r,float g,float b)
{
   glPushMatrix();
   glTranslated(x,y,z);
   glRotated(ry,0,1,0);
   glScaled(dx,dy,dz);
   CubeTex(dx,dy,dz, r,g,b);
   glPopMatrix();
}

static void Tube(double rb,double rt,double h,int n,double urep,
                 float r,float g,float b)
{
   glColor3f(r,g,b);
   /*  Curved wall  */
   glBegin(GL_QUAD_STRIP);
   for (int i=0;i<=n;i++)
   {
      double a = 360.0*i/n;
      double c = Cos(a);
      double s = Sin(a);
      double u = urep*i/n;
      glNormal3d(h*c, rb-rt, h*s);
      glTexCoord2d(u,0); glVertex3d(rb*c,0,rb*s);
      glTexCoord2d(u,1); glVertex3d(rt*c,h,rt*s);
   }
   glEnd();
   /*  Top cap -- radial texture mapping from ex20  */
   glNormal3d(0,1,0);
   glBegin(GL_TRIANGLE_FAN);
   glTexCoord2d(0.5,0.5); glVertex3d(0,h,0);
   for (int i=0;i<=n;i++)
   {
      double a = 360.0*i/n;
      glTexCoord2d(0.5*Cos(a)+0.5, 0.5*Sin(a)+0.5);
      glVertex3d(rt*Cos(a),h,rt*Sin(a));
   }
   glEnd();
   /*  Bottom cap -- reversed winding so normal faces down  */
   glNormal3d(0,-1,0);
   glBegin(GL_TRIANGLE_FAN);
   glTexCoord2d(0.5,0.5); glVertex3d(0,0,0);
   for (int i=n;i>=0;i--)
   {
      double a = 360.0*i/n;
      glTexCoord2d(0.5*Cos(a)+0.5, 0.5*Sin(a)+0.5);
      glVertex3d(rb*Cos(a),0,rb*Sin(a));
   }
   glEnd();
}

static void Dustbin(float r,float g,float b)
{
   Texture(tex_plastic);
   Tube(0.30,0.36,0.80,24,2.0, r,g,b);
   Tube(0.36,0.40,0.06,24,2.0, r*0.7f,g*0.7f,b*0.7f);
   glPushMatrix();
   glTranslated(0,0.86,0);
   Tube(0.42,0.22,0.12,24,2.0, r*0.85f,g*0.85f,b*0.85f);
   glPopMatrix();
   Texture(tex_metal);
   Box(+0.40,0.55,0, 0.10,0.06,0.18, 0, r*0.6f,g*0.6f,b*0.6f);
   Box(-0.40,0.55,0, 0.10,0.06,0.18, 0, r*0.6f,g*0.6f,b*0.6f);
}

static void Wheel(double x,double z,double radius,double width)
{
   Texture(tex_rubber);
   glPushMatrix();
   glTranslated(x,radius,z);
   glRotated(90,0,0,1);
   glTranslated(0,-width/2,0);
   Tube(radius,radius,width,16,6.0, 0.9f,0.9f,0.9f);
   glPopMatrix();
}

static void Lawnmower(float r,float g,float b)
{
   double wr = 0.17;
   double ww = 0.12;
   Wheel(-0.50,-0.34,wr,ww);
   Wheel(+0.50,-0.34,wr,ww);
   Wheel(-0.50,+0.34,wr,ww);
   Wheel(+0.50,+0.34,wr,ww);
   Texture(tex_metal);
   Box(0,0.30,0, 1.20,0.22,0.92, 0, r,g,b);
   Box(-0.10,0.52,0.10, 0.46,0.30,0.52, 0, 0.32f,0.32f,0.34f);
   glPushMatrix();
   glTranslated(0.16,0.66,0.10);
   Tube(0.10,0.08,0.18,12,1.0, 0.55f,0.18f,0.18f);
   glPopMatrix();
   glPushMatrix();
   glTranslated(0,0.34,-0.42);
   glRotated(-52,1,0,0);
   Box(-0.45,0.55,0, 0.06,1.25,0.06, 0, 0.32f,0.32f,0.35f);
   Box(+0.45,0.55,0, 0.06,1.25,0.06, 0, 0.32f,0.32f,0.35f);
   Box(0,1.16,0, 1.02,0.08,0.08, 0, 0.28f,0.28f,0.28f);
   glPopMatrix();
   Texture(tex_plastic);
   Box(0,0.30,-0.62, 0.85,0.40,0.30, 0, 0.20f,0.45f,0.20f);
}

static void Ground(void)
{
   Texture(tex_grass);
   glNormal3f(0,1,0);
   int bands = 18;
   double step = 2*FIELD/bands;
   for (int i=0;i<bands;i++)
   {
      double z0 = -FIELD + i*step;
      double z1 = z0 + step;
      if (i%2) glColor3f(0.85f,0.95f,0.80f);
      else     glColor3f(0.62f,0.80f,0.58f);
      glBegin(GL_QUADS);
      glTexCoord2d(0,       z0+FIELD); glVertex3d(-FIELD,0,z0);
      glTexCoord2d(2*FIELD, z0+FIELD); glVertex3d(+FIELD,0,z0);
      glTexCoord2d(2*FIELD, z1+FIELD); glVertex3d(+FIELD,0,z1);
      glTexCoord2d(0,       z1+FIELD); glVertex3d(-FIELD,0,z1);
      glEnd();
   }
}

static void Fence(void)
{
   Texture(tex_wood);
   double e = FIELD - 0.3;
   for (double t=-e; t<=e+0.01; t+=1.5)
   {
      Box(+e,0.45,t, 0.12,0.9,0.12, 0, 0.66f,0.50f,0.32f);
      Box(-e,0.45,t, 0.12,0.9,0.12, 0, 0.66f,0.50f,0.32f);
      Box(t,0.45,+e, 0.12,0.9,0.12, 0, 0.66f,0.50f,0.32f);
      Box(t,0.45,-e, 0.12,0.9,0.12, 0, 0.66f,0.50f,0.32f);
   }
   Box(+e,0.75,0, 0.08,0.10,2*e, 0, 0.72f,0.55f,0.36f);
   Box(-e,0.75,0, 0.08,0.10,2*e, 0, 0.72f,0.55f,0.36f);
   Box(0,0.75,+e, 2*e,0.10,0.08, 0, 0.72f,0.55f,0.36f);
   Box(0,0.75,-e, 2*e,0.10,0.08, 0, 0.72f,0.55f,0.36f);
}

static void Scene(void)
{
   Ground();
   Fence();

   glPushMatrix();
   glTranslated(-2.5,0,1.0);
   glRotated(25,0,1,0);
   Lawnmower(0.85f,0.16f,0.12f);
   glPopMatrix();

   glPushMatrix();
   glTranslated(2.8,0,-2.0);
   glRotated(-110,0,1,0);
   glScaled(0.8,0.8,0.8);
   Lawnmower(0.90f,0.55f,0.10f);
   glPopMatrix();

   glPushMatrix();
   glTranslated(4.5,0,3.5);
   Dustbin(0.30f,0.55f,0.30f);
   glPopMatrix();

   glPushMatrix();
   glTranslated(5.5,0,3.2);
   glScaled(1.25,1.25,1.25);
   Dustbin(0.25f,0.35f,0.65f);
   glPopMatrix();

   glPushMatrix();
   glTranslated(3.0,0.36,4.5);
   glRotated(90,0,0,1);
   glRotated(30,0,1,0);
   Dustbin(0.55f,0.55f,0.55f);
   glPopMatrix();

   Texture(tex_wood);
   Box(-4.5,0.45,-3.5, 0.9,0.9,0.9,  20, 0.72f,0.52f,0.30f);
   Box(-3.7,0.35,-3.0, 0.7,0.7,0.7, -15, 0.78f,0.56f,0.34f);
   Box(-4.2,1.10,-3.5, 0.7,0.7,0.7,   5, 0.75f,0.54f,0.32f);
}

/* =========================================================
 *  SUN / LIGHTING
 * ========================================================= */
static void DrawSun(void)
{
   int   slices = 32;
   float radius = 0.4f;
   float rayLen = 0.5f;
   int   rays   = 12;

   glDisable(GL_LIGHTING);
   glDisable(GL_TEXTURE_2D);
   //Filled sun disk (triangle fan = circle)  
   glColor3f(1.0f, 0.95f, 0.3f);
   glBegin(GL_TRIANGLE_FAN);
   glVertex3f(0,0,0);
   for (int i=0;i<=slices;i++)
   {
      float a = 360.0f*i/slices;
      glVertex3f(radius*Cos(a), radius*Sin(a), 0);
   }
   glEnd();
      
    //Rays: thin triangles pointing outward from the disk edge  
   glColor3f(1.0f, 0.75f, 0.0f);
   for (int i=0;i<rays;i++)
   {
      float a  = 360.0f*i/rays;
      float a1 = a - 7.0f;
      float a2 = a + 7.0f;
      glBegin(GL_TRIANGLES);
      glVertex3f(radius*Cos(a1), radius*Sin(a1), 0);
      glVertex3f(radius*Cos(a2), radius*Sin(a2), 0);
      glVertex3f(rayLen *Cos(a),  rayLen*Sin(a),  0);
      glEnd();
   }
   
}

/*
 *  Set up GL_LIGHT0 as a sun that travels East (+X) to West (-X).
 *  zh=0   : East horizon (sunrise)
 *  zh=90  : directly overhead (noon)
 *  zh=180 : West horizon (sunset)
 *  zh>180 : below ground (night) -- only dim blue ambient, no sun drawn
 *
 *  Lx, Ly, Lz are the pre-computed world position of the sun; zh is the
 *  global angle used to derive the time-of-day colour.
 */
static void Lighting(double Lx, double Ly, double Lz)
{
  
   float day   = (float)Sin(zh);
   float above = day > 0.0f ? day : 0.0f;  
   float Diffuse[] = {above*0.9f, above*0.85f, above*0.75f, 1.0f};
   float tint = (above > 0.0f && above < 0.35f) ? (0.35f-above)/0.35f : 0.0f;
   Diffuse[0] += tint * 0.5f;        
   Diffuse[2] -= tint * 0.45f;      
   if (Diffuse[2] < 0.0f) Diffuse[2] = 0.0f;
   float Ambient[] = {
      above > 0.0f ? 0.08f + above*0.22f : 0.04f,
      above > 0.0f ? 0.08f + above*0.22f : 0.04f,
      above > 0.0f ? 0.08f + above*0.18f : 0.12f,
      1.0f
   };

   float s        = above * 0.35f;
   float Specular[]= {s, s, s, 1.0f};
   float spec[]    = {0.3f, 0.3f, 0.3f, 1.0f};

   if (Ly > 0.0)
   {
      glPushMatrix();
      glTranslated(Lx, Ly, Lz);
      glRotated(zh, 0, 0, 1);
      DrawSun();
      glPopMatrix();
   }

   /*  --- Configure GL_LIGHT0  ---  */
   float Position[] = {(float)Lx, (float)Ly, (float)Lz, 1.0f};
   glEnable(GL_NORMALIZE);
   glEnable(GL_LIGHTING);
   glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
   glEnable(GL_COLOR_MATERIAL);
   glEnable(GL_LIGHT0);
   glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 16);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR,  spec);
   glLightfv(GL_LIGHT0, GL_AMBIENT,  Ambient);
   glLightfv(GL_LIGHT0, GL_DIFFUSE,  Diffuse);
   glLightfv(GL_LIGHT0, GL_SPECULAR, Specular);
   glLightfv(GL_LIGHT0, GL_POSITION, Position);
}

/* =========================================================
 *  GLUT CALLBACKS
 * ========================================================= */

void display(void)
{
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
   glEnable(GL_DEPTH_TEST);
   glLoadIdentity();
   if (mode==2)
   {
      double lx = Cos(fpPh)*Sin(fpTh);
      double ly = Sin(fpPh);
      double lz = -Cos(fpPh)*Cos(fpTh);
      gluLookAt(Ex,Ey,Ez, Ex+lx,Ey+ly,Ez+lz, 0,1,0);
   }
   else if (mode==1)
   {
      double Px = -2*dim*Sin(th)*Cos(ph);
      double Py = +2*dim*Sin(ph);
      double Pz = +2*dim*Cos(th)*Cos(ph);
      gluLookAt(Px,Py,Pz, 0,0,0, 0,Cos(ph),0);
   }
   else
   {
      glRotatef(ph,1,0,0);
      glRotatef(th,0,1,0);
   }
   double Lx = LR * Cos(zh);
   double Ly = LR * Sin(zh);
   double Lz = 0;

   if (light)
      Lighting(Lx, Ly, Lz);
   else
      glDisable(GL_LIGHTING);

   /*  Texture environment: modulate so colour tints the texture  */
   glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

   /*  Draw the scene  */
   Scene();

   /*  Axes -- no lighting or texture  */
   glDisable(GL_LIGHTING);
   glDisable(GL_TEXTURE_2D);
   if (axes)
   {
      const double len = 2.0;
      glColor3f(1,1,1);
      glBegin(GL_LINES);
      glVertex3d(0,0,0); glVertex3d(len,0,0);
      glVertex3d(0,0,0); glVertex3d(0,len,0);
      glVertex3d(0,0,0); glVertex3d(0,0,len);
      glEnd();
      glRasterPos3d(len,0,0); Print("X");
      glRasterPos3d(0,len,0); Print("Y");
      glRasterPos3d(0,0,len); Print("Z");
   }

   const char* name = (mode==0) ? "Overhead Orthogonal" :
                      (mode==1) ? "Overhead Perspective" : "First Person";
   const char* tod  = (Ly>0) ? (Sin(zh)<0.35f?"Sunrise/Sunset":"Day") : "Night";
   glColor3f(1,1,1);

   /*   current view state  */
   glWindowPos2i(5,85);
   if (mode==2)
      Print("Mode=%s  Pos=(%.1f,%.1f)  Heading=%d  FOV=%d",
            name,Ex,Ez,(int)fpTh,fov);
   else
      Print("Mode=%s  Angle=%d,%d  Dim=%.1f  FOV=%d",
            name,th,ph,dim,fov);

   /*  sun / lighting / texture state  */
   glWindowPos2i(5,65);
   Print("Sun=%s  Time=%s  zh=%.0f  Textures=%s  Axes=%s",
         light?"On":"Off", tod, zh, ntex?"On":"Off", axes?"On":"Off");

   /*  view controls  */
   glWindowPos2i(5,45);
   if (mode==2)
      Print("View: arrows=Look  WASD=Walk  m=Cycle  1/2/3=Mode  PgUp/Dn=Zoom  +/-=FOV");
   else
      Print("View: arrows=Orbit  m=Cycle  1/2/3=Mode  PgUp/Dn=Zoom  +/-=FOV  b=Axes");

   /*  sun / scene controls  */
   glWindowPos2i(5,25);
   Print("Sun:  space=Pause/Resume  ,/.=Move  l=Toggle Lighting  t=Toggle Textures");

   /*  reset and exit  */
   glWindowPos2i(5,5);
   Print("0=Reset All  ESC/q=Exit");

   ErrCheck("display");
   glFlush();
   glutSwapBuffers();
}


void idle(void)
{
   static double last = 0;
   double t = glutGet(GLUT_ELAPSED_TIME)/1000.0;
   if (move)
   {
      zh = fmod(zh + 36*(t-last), 360.0);  
      glutPostRedisplay();
   }
   last = t;
}

/*
 *  Set the projection matrix for the active view mode. 
 */
static void SetProjection(void)
{
   if (mode==0)
      Project(0,asp,dim);
   else if (mode==1)
      Project(fov,asp,dim);
   else
      Project(70,asp,dim);
}

/*
 *  Arrow / page keys.
 */
void special(int key,int x,int y)
{
   (void)x; (void)y;
   if (mode==2)
   {
      if      (key==GLUT_KEY_RIGHT) fpTh += 4;
      else if (key==GLUT_KEY_LEFT)  fpTh -= 4;
      else if (key==GLUT_KEY_UP)    fpPh += 3;
      else if (key==GLUT_KEY_DOWN)  fpPh -= 3;
      if (fpPh> 85) fpPh =  85;
      if (fpPh<-85) fpPh = -85;
      if (fpTh>=360) fpTh -= 360;
      if (fpTh<  0)  fpTh += 360;
   }
   else
   {
      if      (key==GLUT_KEY_RIGHT)     th += 5;
      else if (key==GLUT_KEY_LEFT)      th -= 5;
      else if (key==GLUT_KEY_UP)        ph += 5;
      else if (key==GLUT_KEY_DOWN)      ph -= 5;
      else if (key==GLUT_KEY_PAGE_UP)   dim += 0.5;
      else if (key==GLUT_KEY_PAGE_DOWN) dim -= 0.5;
      th %= 360;
      ph %= 360;
      if (dim<2) dim = 2;
   }
   SetProjection();
   glutPostRedisplay();
}

/*
 *  Ordinary key handler.
 *  [navigation keys from hw2; sun/texture keys new for hw3,
 *  plus reset and exit]
 */
void key(unsigned char ch,int x,int y)
{
   (void)x; (void)y;
   double step = 0.4;

   if (ch==27 || ch=='q' || ch=='Q')
      exit(0);
   else if (ch=='0')
   {
      /*  Reset everything to defaults  */
      th=35; ph=30; dim=9.0; fov=55;
      Ex=0; Ey=1.3; Ez=7; fpTh=0; fpPh=-8;
      light=1; move=1; ntex=1; zh=10;
   }
   else if (ch=='b' || ch=='B')
      axes = 1-axes;
   else if (ch=='1') mode = 0;
   else if (ch=='2') mode = 1;
   else if (ch=='3') mode = 2;
   else if (ch=='m' || ch=='M')
      mode = (mode+1)%3;
   else if (ch=='l' || ch=='L')
      light = 1-light;
   else if (ch==' ')                          /*  pause/resume sun  */
      move = 1-move;
   else if (ch==',')                          /*  move sun back  */
      zh = fmod(zh-5+360, 360);
   else if (ch=='.')                          /*  move sun forward  */
      zh = fmod(zh+5, 360);
   else if (ch=='t' || ch=='T')
      ntex = 1-ntex;
   else if (ch=='-' && fov>5)   fov--;
   else if (ch=='+' && fov<160) fov++;
   /*  First person walking  [hw2]  */
   else if (mode==2 && (ch=='w'||ch=='W'))
   { Ex += step*Sin(fpTh); Ez -= step*Cos(fpTh); }
   else if (mode==2 && (ch=='s'||ch=='S'))
   { Ex -= step*Sin(fpTh); Ez += step*Cos(fpTh); }
   else if (mode==2 && (ch=='d'||ch=='D'))
   { Ex += step*Cos(fpTh); Ez += step*Sin(fpTh); }
   else if (mode==2 && (ch=='a'||ch=='A'))
   { Ex -= step*Cos(fpTh); Ez -= step*Sin(fpTh); }

   /*  Keep walker inside the field  [hw2]  */
   if (Ex> FIELD-0.5) Ex =  FIELD-0.5;
   if (Ex<-FIELD+0.5) Ex = -FIELD+0.5;
   if (Ez> FIELD-0.5) Ez =  FIELD-0.5;
   if (Ez<-FIELD+0.5) Ez = -FIELD+0.5;

   SetProjection();
   glutPostRedisplay();
}

void reshape(int width,int height)
{
   asp = (height>0) ? (double)width/height : 1;
   glViewport(0,0, width,height);
   SetProjection();
}

int main(int argc,char* argv[])
{
   glutInit(&argc,argv);
   glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
   glutInitWindowSize(800,600);
   glutCreateWindow("Homework 3 - Lighting and Textures - Prithvikiran");

#ifdef USEGLEW
   if (glewInit()!=GLEW_OK) Fatal("Error initializing GLEW\n");
#endif

   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutSpecialFunc(special);
   glutKeyboardFunc(key);
   glutIdleFunc(idle);

   /*  Load procedurally-made 128x128 textures */
   tex_grass   = LoadTexBMP("Textures/grass.bmp");
   tex_wood    = LoadTexBMP("Textures/wood.bmp");
   tex_metal   = LoadTexBMP("Textures/metal.bmp");
   tex_plastic = LoadTexBMP("Textures/plastic.bmp");
   tex_rubber  = LoadTexBMP("Textures/rubber.bmp");

   ErrCheck("init");
   glutMainLoop();
   return 0;
}
