
#include "CSCIx229.h"

/*  -----  View / projection state (based on ex9.c)  -----  */
int    mode = 1;     //  Projection: 1=overhead ortho, 2=overhead perspective, 3=first person
int    axes = 0;     //  Display axes (based on ex10)
int    th   = 35;    //  Azimuth of view angle for the overhead modes
int    ph   = 30;    //  Elevation of view angle for the overhead modes
int    fov  = 55;    //  Field of view for perspective (ex9)
double asp  = 1;     //  Aspect ratio (ex9)
double dim  = 9.0;   //  Size of world (ex9)

/*  -----  First person camera state  -----  */
double Ex = 0;       //  Eye position
double Ey = 1.3;     //  Eye height (kept above the ground)
double Ez = 7;
double fpTh = 0;     //  First person heading (yaw, degrees)
double fpPh = -8;    //  First person pitch (degrees)

#define FIELD 9.0    //  Half width of the square field

/*
 *  Apply a colour scaled by a brightness factor.
 *  Faking depth with per-face brightness uses only glColor3f, which is the
 *  colour concept shown in ex9 and ex12. A way make objects look better without lighting [ DARKER AND BRIGHTER SHADES OF THE SAME COLOUR ] 
 */
static void Shade(float r,float g,float b,float f)
{
   glColor3f(r*f,g*f,b*f);
}

/*
 *  Generic unit cube centred at the origin, drawn in a single base colour
 *  with each face shaded slightly differently to suggest depth.
 *  Adapted from the cube() routine in ex9 (one colour instead of six).
 */
static void Cube(float r,float g,float b)
{
   glBegin(GL_QUADS);
   //  Top
   Shade(r,g,b,1.00f);
   glVertex3d(-0.5,+0.5,-0.5); glVertex3d(-0.5,+0.5,+0.5);
   glVertex3d(+0.5,+0.5,+0.5); glVertex3d(+0.5,+0.5,-0.5);
   //  Bottom
   Shade(r,g,b,0.45f);
   glVertex3d(-0.5,-0.5,-0.5); glVertex3d(+0.5,-0.5,-0.5);
   glVertex3d(+0.5,-0.5,+0.5); glVertex3d(-0.5,-0.5,+0.5);
   //  Front
   Shade(r,g,b,0.80f);
   glVertex3d(-0.5,-0.5,+0.5); glVertex3d(+0.5,-0.5,+0.5);
   glVertex3d(+0.5,+0.5,+0.5); glVertex3d(-0.5,+0.5,+0.5);
   //  Back
   Shade(r,g,b,0.65f);
   glVertex3d(+0.5,-0.5,-0.5); glVertex3d(-0.5,-0.5,-0.5);
   glVertex3d(-0.5,+0.5,-0.5); glVertex3d(+0.5,+0.5,-0.5);
   //  Right
   Shade(r,g,b,0.72f);
   glVertex3d(+0.5,-0.5,+0.5); glVertex3d(+0.5,-0.5,-0.5);
   glVertex3d(+0.5,+0.5,-0.5); glVertex3d(+0.5,+0.5,+0.5);
   //  Left
   Shade(r,g,b,0.55f);
   glVertex3d(-0.5,-0.5,-0.5); glVertex3d(-0.5,-0.5,+0.5);
   glVertex3d(-0.5,+0.5,+0.5); glVertex3d(-0.5,+0.5,-0.5);
   glEnd();
}

/*
 *  Convenience: place a coloured box. ex9 [ cube ].
 */
static void Box(double x,double y,double z,
                double dx,double dy,double dz,double ry,
                float r,float g,float b)
{
   glPushMatrix();
   glTranslated(x,y,z);
   glRotated(ry,0,1,0);
   glScaled(dx,dy,dz);
   Cube(r,g,b);
   glPopMatrix();
}

/*
 *  Generic tapered tube (a frustum) built around the +y axis.
 *  Cos()/Sin() macros declared in CSCIx229.h .
 */
static void Tube(double rb,double rt,double h,int n,float r,float g,float b)
{
   Shade(r,g,b,0.80f);
   glBegin(GL_QUAD_STRIP);// A shape not in examples, i used GL_QUAD_STRIP to draw the tube. It is a strip of quads that wraps around the tube. 
   for (int i=0;i<=n;i++)
   {
      double a = 360.0*i/n;
      double c = Cos(a);
      double s = Sin(a);
      glVertex3d(rb*c,0,rb*s);
      glVertex3d(rt*c,h,rt*s);
   }
   glEnd();
   Shade(r,g,b,1.00f);
   glBegin(GL_TRIANGLE_FAN);
   glVertex3d(0,h,0);
   for (int i=0;i<=n;i++)
   {
      double a = 360.0*i/n;
      glVertex3d(rt*Cos(a),h,rt*Sin(a));
   }
   glEnd();

   Shade(r,g,b,0.45f);
   glBegin(GL_TRIANGLE_FAN); // Needed to draw a circular cap like structure so i used GL_TRIANGLE_FAN . A shape not in examples.
   glVertex3d(0,0,0);
   for (int i=0;i<=n;i++)
   {
      double a = 360.0*i/n;
      glVertex3d(rb*Cos(a),0,rb*Sin(a));
   }
   glEnd();
}


static void Dustbin(float r,float g,float b)
{
   
   Tube(0.30,0.36,0.80,24,r,g,b);
   Tube(0.36,0.40,0.06,24,r*0.7f,g*0.7f,b*0.7f);
   glPushMatrix();
   glTranslated(0,0.86,0);
   Tube(0.42,0.22,0.12,24,r*0.85f,g*0.85f,b*0.85f);
   glPopMatrix();
   Box(+0.40,0.55,0,0.10,0.06,0.18,0,r*0.6f,g*0.6f,b*0.6f);
   Box(-0.40,0.55,0,0.10,0.06,0.18,0,r*0.6f,g*0.6f,b*0.6f);
}

/*
 *  One lawnmower wheel: a short tube lying on its side (axle along x),
 *  centred on the local origin.
 */
static void Wheel(double x,double z,double radius,double width)
{
   glPushMatrix();
   glTranslated(x,radius,z);
   glRotated(90,0,0,1);          //  Stand the tube up onto the x axis
   glTranslated(0,-width/2,0);   //  Centre its width
   Tube(radius,radius,width,16,0.12f,0.12f,0.12f);
   glPopMatrix();
}

static void Lawnmower(float r,float g,float b)
{
   double wr = 0.17;   //  Wheel radius
   double ww = 0.12;   //  Wheel width
   //  Four wheels
   Wheel(-0.50,-0.34,wr,ww);
   Wheel(+0.50,-0.34,wr,ww);
   Wheel(-0.50,+0.34,wr,ww);
   Wheel(+0.50,+0.34,wr,ww);
   //  Deck (main coloured body)
   Box(0,0.30,0, 1.20,0.22,0.92, 0, r,g,b);
   //  Engine block on top, toward the front
   Box(-0.10,0.52,0.10, 0.46,0.30,0.52, 0, 0.22f,0.22f,0.24f);
   //  Air filter / spark plug stack on the engine
   glPushMatrix();
   glTranslated(0.16,0.66,0.10);
   Tube(0.10,0.08,0.18,12,0.45f,0.10f,0.10f);
   glPopMatrix();
   
   glPushMatrix();
   glTranslated(0,0.34,-0.42);     
   glRotated(-52,1,0,0);          
   //  Two side bars
   Box(-0.45,0.55,0, 0.06,1.25,0.06, 0, 0.15f,0.15f,0.18f);
   Box(+0.45,0.55,0, 0.06,1.25,0.06, 0, 0.15f,0.15f,0.18f);
   
   Box(0,1.16,0, 1.02,0.08,0.08, 0, 0.10f,0.10f,0.10f);
   glPopMatrix();
   //  Grass catcher bag at the back, near the ground
   Box(0,0.30,-0.62, 0.85,0.40,0.30, 0, 0.20f,0.45f,0.20f);
}


//  Grassy ground as alternating mowed stripes.
//  Pure coloured quads (the colour concept from ex12).
 
static void Ground(void)
{
   int bands = 18;
   double step = 2*FIELD/bands;
   for (int i=0;i<bands;i++)
   {
      double z0 = -FIELD + i*step;
      double z1 = z0 + step;
      //  Two shades of green for the cut-grass stripe look
      if (i%2) glColor3f(0.28f,0.55f,0.22f);
      else     glColor3f(0.33f,0.62f,0.26f);
      glBegin(GL_QUADS); // from the example code in ex10,12.
      glVertex3d(-FIELD,0,z0);
      glVertex3d(+FIELD,0,z0);
      glVertex3d(+FIELD,0,z1);
      glVertex3d(-FIELD,0,z1);
      glEnd();
   }
}

/*
 *  A low perimeter fence made from generic boxes (posts and a top rail).
 */
static void Fence(void)
{
   double e = FIELD - 0.3;     
  
   for (double t=-e; t<=e+0.01; t+=1.5)
   {
      Box(+e,0.45,t, 0.12,0.9,0.12, 0, 0.55f,0.40f,0.25f);
      Box(-e,0.45,t, 0.12,0.9,0.12, 0, 0.55f,0.40f,0.25f);
      Box(t,0.45,+e, 0.12,0.9,0.12, 0, 0.55f,0.40f,0.25f);
      Box(t,0.45,-e, 0.12,0.9,0.12, 0, 0.55f,0.40f,0.25f);
   }
   //  Top rails (long thin boxes along each edge)
   Box(+e,0.75,0, 0.08,0.10,2*e, 0, 0.62f,0.46f,0.30f);
   Box(-e,0.75,0, 0.08,0.10,2*e, 0, 0.62f,0.46f,0.30f);
   Box(0,0.75,+e, 2*e,0.10,0.08, 0, 0.62f,0.46f,0.30f);
   Box(0,0.75,-e, 2*e,0.10,0.08, 0, 0.62f,0.46f,0.30f);
}

/*
 *  Compose the whole scene. The two lawnmowers and the three dustbins .
 */
static void Scene(void)
{
   Ground();
   Fence();

  
   glPushMatrix();
   glTranslated(-2.5,0,1.0);
   glRotated(25,0,1,0);
   Lawnmower(0.85f,0.16f,0.12f);
   glPopMatrix();
 
   glPushMatrix();
   glTranslated(2.8,0,-2.0);
   glRotated(-110,0,1,0);
   glScaled(0.8,0.8,0.8);
   Lawnmower(0.90f,0.55f,0.10f);
   glPopMatrix();


   // Green bin
   glPushMatrix();
   glTranslated(4.5,0,3.5);
   Dustbin(0.30f,0.55f,0.30f);
   glPopMatrix();
   //  Blue bin, larger
   glPushMatrix();
   glTranslated(5.5,0,3.2);
   glScaled(1.25,1.25,1.25);
   Dustbin(0.25f,0.35f,0.65f);
   glPopMatrix();
   //  Grey bin
   glPushMatrix();
   glTranslated(3.0,0.36,4.5);
   glRotated(90,0,0,1);
   glRotated(30,0,1,0);
   Dustbin(0.55f,0.55f,0.55f);
   glPopMatrix();

   //  A couple of wooden crates (instances of the generic Cube)
   Box(-4.5,0.45,-3.5, 0.9,0.9,0.9, 20, 0.55f,0.38f,0.20f);
   Box(-3.7,0.35,-3.0, 0.7,0.7,0.7, -15,0.60f,0.42f,0.24f);
   Box(-4.2,1.10,-3.5, 0.7,0.7,0.7, 5,  0.58f,0.40f,0.22f);
}

void display(void)
{
   //  Erase the window and the depth buffer
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
   //  Enable hidden surface removal (ex10.c)
   glEnable(GL_DEPTH_TEST);
   //  Undo previous transformations
   glLoadIdentity();

   if (mode==2)
   {
      //  First person: look in the heading/pitch direction (gluLookAt, ex9)
      double lx = Cos(fpPh)*Sin(fpTh);
      double ly = Sin(fpPh);
      double lz = -Cos(fpPh)*Cos(fpTh);
      gluLookAt(Ex,Ey,Ez, Ex+lx,Ey+ly,Ez+lz, 0,1,0);
   }
   else if (mode==1)
   {
      //  Overhead perspective: (ex9)
      double Px = -2*dim*Sin(th)*Cos(ph);
      double Py = +2*dim*Sin(ph);
      double Pz = +2*dim*Cos(th)*Cos(ph);
      gluLookAt(Px,Py,Pz, 0,0,0, 0,Cos(ph),0);
   }
   else
   {
      //  Overhead orthogonal: rotate the world (ex9)
      glRotatef(ph,1,0,0);
      glRotatef(th,0,1,0);
   }

    
   Scene();

   //  Draw axes (ex10)
   if (axes)
   {
      const double len = 2.0;
      glColor3f(1,1,1);
      glBegin(GL_LINES);
      glVertex3d(0,0,0); glVertex3d(len,0,0);
      glVertex3d(0,0,0); glVertex3d(0,len,0);
      glVertex3d(0,0,0); glVertex3d(0,0,len);
      glEnd();
      glRasterPos3d(len,0,0); Print("X");
      glRasterPos3d(0,len,0); Print("Y");
      glRasterPos3d(0,0,len); Print("Z");
   }

   
   const char* name = (mode==0) ? "Overhead Orthogonal" :
                      (mode==1) ? "Overhead Perspective" : "First Person";
   glColor3f(1,1,1);
   glWindowPos2i(5,5);
   if (mode==2)
      Print("Mode=%s  Pos=%.1f,%.1f  Heading=%d  FOV=%d  (m,1/2/3 change view)",
            name,Ex,Ez,(int)fpTh,fov);
   else
      Print("Mode=%s  Angle=%d,%d  Dim=%.1f  FOV=%d  (m,1/2/3 change view)",
            name,th,ph,dim,fov);

  
   ErrCheck("display");
   glFlush();
   glutSwapBuffers();
}


static void SetProjection(void)
{
   if (mode==0)
      Project(0,asp,dim);        // overhead orthogonal
   else if (mode==1)
      Project(fov,asp,dim);      // overhead perspective
   else
      Project(70,asp,dim);       // first person - wider FOV
}


void special(int key,int x,int y)
{
   (void)x; (void)y;
   if (mode==2)
   {
      //  First person: arrows look around
      if      (key==GLUT_KEY_RIGHT) fpTh += 4;
      else if (key==GLUT_KEY_LEFT)  fpTh -= 4;
      else if (key==GLUT_KEY_UP)    fpPh += 3;
      else if (key==GLUT_KEY_DOWN)  fpPh -= 3;
      //  Keep pitch sensible and wrap heading
      if (fpPh>85)  fpPh = 85;
      if (fpPh<-85) fpPh = -85;
      if (fpTh>=360) fpTh -= 360;
      if (fpTh<0)    fpTh += 360;
   }
   else
   {
      //  Overhead: arrows orbit, PageUp/PageDown zoom
      if      (key==GLUT_KEY_RIGHT)     th += 5;
      else if (key==GLUT_KEY_LEFT)      th -= 5;
      else if (key==GLUT_KEY_UP)        ph += 5;
      else if (key==GLUT_KEY_DOWN)      ph -= 5;
      else if (key==GLUT_KEY_PAGE_UP)   dim += 0.5;
      else if (key==GLUT_KEY_PAGE_DOWN) dim -= 0.5;
      //  Keep angles in range and the view from collapsing
      th %= 360;
      ph %= 360;
      if (dim<2) dim = 2;
   }
   SetProjection();
   glutPostRedisplay();
}


void key(unsigned char ch,int x,int y)
{
   (void)x; (void)y;
   double step = 0.4;   //  First person walk speed
   
   if (ch==27 || ch=='q' || ch=='Q')
      exit(0);
   //  Reset view
   else if (ch=='0')
   {
      th = 35; ph = 30; dim = 9.0; fov = 55;
      Ex = 0; Ey = 1.3; Ez = 7; fpTh = 0; fpPh = -8;
   }
   //  Toggle axes
   else if (ch=='b' || ch=='B')
      axes = 1-axes;
   //  Choose projection mode directly
   else if (ch=='1') mode = 0;
   else if (ch=='2') mode = 1;
   else if (ch=='3') mode = 2;
   //  Cycle projection mode -> changes the modes in the order 1->2->3->1...
   else if (ch=='m' || ch=='M')
      mode = (mode+1)%3;
   //  Field of view for perspective
   else if (ch=='-' && fov>5)   fov--;
   else if (ch=='+' && fov<160) fov++;
   //  First person movement (walk on the ground plane)
   else if (mode==2 && (ch=='w'||ch=='W'))
   {
      Ex += step*Sin(fpTh); Ez -= step*Cos(fpTh);
   }
   else if (mode==2 && (ch=='s'||ch=='S'))
   {
      Ex -= step*Sin(fpTh); Ez += step*Cos(fpTh);
   }
   else if (mode==2 && (ch=='d'||ch=='D'))
   {
      Ex += step*Cos(fpTh); Ez += step*Sin(fpTh);
   }
   else if (mode==2 && (ch=='a'||ch=='A'))
   {
      Ex -= step*Cos(fpTh); Ez -= step*Sin(fpTh);
   }
   //  Keep the walker inside the field (reasonable navigation limit)
   if (Ex>FIELD-0.5)  Ex = FIELD-0.5;
   if (Ex<-FIELD+0.5) Ex = -FIELD+0.5;
   if (Ez>FIELD-0.5)  Ez = FIELD-0.5;
   if (Ez<-FIELD+0.5) Ez = -FIELD+0.5;

   SetProjection();
   glutPostRedisplay();
}


void reshape(int width,int height)
{
   asp = (height>0) ? (double)width/height : 1;
   glViewport(0,0, width,height);
   SetProjection();
}

//  Start up GLUT and tell it what to do
int main(int argc,char* argv[])
{
   glutInit(&argc,argv);
   glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
   glutInitWindowSize(800,600);
   glutCreateWindow(" Green Field - [ Scene in 3D] - Prithvikiran");

#ifdef USEGLEW
   if (glewInit()!=GLEW_OK) Fatal("Error initializing GLEW\n");
#endif
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutSpecialFunc(special);
   glutKeyboardFunc(key);
   ErrCheck("init");
   glutMainLoop();
   return 0;
}
